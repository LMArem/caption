# ウィッチクラフトワークス<br>魔女的使命<br>Witchikurafuto Wākusu

<img src="img.png" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [Fandom](https://witch-craft-works.fandom.com/wiki/Witch_Craft_Works_Wiki)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|RH字幕组|
|集数|OAD|
|语言|简体中文|
|时间轴匹配|缺失|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|未获取, 仅供学习交流|

## 歌曲歌词信息

|主题曲|歌词语言 & 来源|
|-|-|
|divine intervention|[日语歌词](https://utaten.com/lyric/xs15020413)|
|ウィッチ☆アクティビティ|[日语歌词](https://utaten.com/lyric/yc16012934)|
