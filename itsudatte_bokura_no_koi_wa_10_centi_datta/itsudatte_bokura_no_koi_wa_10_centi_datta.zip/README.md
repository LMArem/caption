# いつだって僕らの恋は10センチだった。<br/>无论何时我们的恋情都是10厘米。<br/>Itsu Datte Bokura no Koi wa 10 Centi Datta.

<img src="img.jpg" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [Sens Critique](https://www.senscritique.com/serie/We_Have_Always_Been_10_cm_Apart/28746451/images)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|DHR動研字幕組|
|集数|EP 01-06|
|语言|繁體中文|
|时间轴匹配|BD版(jsum@U2)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|已获取|

## 歌曲歌词信息

|主题曲|歌词语言 & 来源|
|-|-|
|ノンファンタジー|[日语歌词](https://www.jpmarumaru.com/tw/JPSongPlay-10842.html)<br>[中文歌词](https://www.jpmarumaru.com/tw/JPSongPlay-10842.html)|
|東京ウインターセッション|[日语歌词](https://www.jpmarumaru.com/tw/JPSongPlay-10953.html)<br>[中文歌词](https://www.jpmarumaru.com/tw/JPSongPlay-10953.html)|
|Re:初恋の絵本|[日语歌词](https://utaten.com/movie/sa15113027)<br>[中文歌词](https://music.163.com/#/song?id=522511653)|
|必要不可欠|[日语歌词](https://www.jpmarumaru.com/tw/JPSongPlay-10878.html)<br>[中文歌词](https://music.163.com/#/song?id=523046070)|
|聞こえますか|[日语歌词](https://www.jpmarumaru.com/tw/JPSongPlay-11641.html)<br>[中文歌词](https://www.jpmarumaru.com/tw/JPSongPlay-11641.html)|
|恋という贈り物|[日语歌词](https://utaten.com/movie/qk00030774)<br>[中文歌词](https://music.163.com/#/song?id=522529625)|
