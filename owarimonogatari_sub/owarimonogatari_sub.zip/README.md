# 終物語<br>终物语<br>Owarimonogatari

<img src="img.png" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [終物語 官方网站](https://www.monogatari-series.com/owarimonogatari/)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|华盟字幕组|
|集数|EP 01-13 [副音轨]|
|语言|简体中文|
|时间轴匹配|BD版(VCB-Studio)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|未获取, 仅供学习交流|
