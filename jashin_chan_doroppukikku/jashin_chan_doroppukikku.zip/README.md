# 邪神ちゃんドロップキック<br>小邪神飛踢<br>邪神与厨二病少女<br>Jashin-chan Doroppukikku

<img src="img.jpg" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [邪神ちゃんドロップキック 官方网站](http://jashinchan.com/)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|DHR百合組|
|集数|EP 01-12|
|语言|繁體中文|
|时间轴匹配|BD版(VCB-Studio)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|已获取|
