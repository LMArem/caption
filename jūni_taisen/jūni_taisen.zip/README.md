# じゅうにたいせん<br>十二大战<br>Jūni Taisen

<img src="img.jpg" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [じゅうにたいせん 官方网站](https://12taisen.com/)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|Bilibili 羚邦|
|集数|EP 01-12|
|语言|简体中文|
|时间轴匹配|BD(jsum@U2)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|未获取, 仅供学习交流|

## 歌曲歌词信息

|主题曲|歌词语言 & 来源|
|-|-|
|ラプチャ|[日语歌词](https://utaten.com/lyric/yc17101201)<br>[中文歌词](https://music.163.com/#/song?id=509728729)|
|化身の獣|[日语歌词](https://utaten.com/lyric/sa17103004)<br>[中文歌词](https://music.163.com/#/song?id=512100312)|
