# 推しが武道館いってくれたら死ぬ<br>神推偶像登上武道馆我就死而无憾<br>Oshi ga Budōkan Ittekuretara Shinu

<img src="img.jpg" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [oshibudo 官方网站](https://oshibudo.com)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|DHR百合組|
|集数|EP 01-12|
|语言|繁體中文|
|时间轴匹配|TV|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|已获取|

## 歌曲歌词信息

|主题曲|歌词语言 & 来源|
|-|-|
|Clover wish|[日语歌词](https://utaten.com/lyric/nm20012206)|
|♡桃色片想い♡|[日语歌词](https://utaten.com/lyric/nm20012243)|
|ずっと ChamJam|[日语歌词](https://utaten.com/lyric/nm20021220)|
|ほっと♡サマーホリデー|[日语歌词](https://utaten.com/lyric/nm20021221)|
|私たちが武道館にいったら|[日语歌词](http://yamanashihonoka.pixnet.net/blog/post/323172892)|

## 说明
- 参考 [推しが武道館いってくれたら死ぬ Wiki (日本語)](https://ja.wikipedia.org/wiki/%E6%8E%A8%E3%81%97%E3%81%8C%E6%AD%A6%E9%81%93%E9%A4%A8%E3%81%84%E3%81%A3%E3%81%A6%E3%81%8F%E3%82%8C%E3%81%9F%E3%82%89%E6%AD%BB%E3%81%AC), 修改源字幕的曲名(原: Hot Summer Holiday; 改: ほっと♡サマーホリデー)
