# ノブナガ・ザ・フール<br>愚者信长<br>Nobunaga za Fūru

<img src="img.png" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [Fandom](https://nobunaga-the-fool.fandom.com/wiki/Nobunaga_the_Fool_Wiki)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|DHR動研 & NTR字幕 & 天上人間|
|集数|EP 01-24|
|语言|繁體中文|
|时间轴匹配|BD版(philosophy-raws)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|已获取|

## 歌曲歌词信息

|主题曲|歌词语言 & 来源|
|-|-|
|FOOL THE WORLD|[日语歌词](https://utaten.com/lyric/jb51403136)<br>[中文歌词](https://music.163.com/#/song?id=28274053)|
|Breakthrough|[日语歌词](https://utaten.com/lyric/sa15062324)<br>[中文歌词](https://y.qq.com/n/yqq/song/000lJj3V1Pt7p4.html)|
|AXIS|[日语歌词](https://utaten.com/lyric/sa15082802)<br>[中文歌词](https://music.163.com/#/song?id=28253230)|
|蘭(RAN)|[日语歌词](https://utaten.com/lyric/to16064097)<br>[中文歌词](https://music.163.com/#/song?id=28546092)|
|アメツチの謳(うた)|[日语歌词](https://utaten.com/lyric/yh15121043)|

## 说明

- 参考 [愚者信长 Wiki (简中)](https://zh.wikipedia.org/wiki/%E6%84%9A%E8%80%85%E4%BF%A1%E9%95%B7), 修改源字幕部分用语
- 修正源字幕中的错字
