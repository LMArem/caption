# 劇場版 ソードアート・オンライン -オーディナル・スケール<br>刀劍神域劇場版：序列爭戰<br>刀剑神域: 序列之争<br>Sword Art Online The Movie Ordinal Scale

<img src="img.jpg" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [劇場版 ソードアート・オンライン -オーディナル・スケール 官方网站](https://sao-movie.net/)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|唯梦字幕组|
|集数|SP01|
|语言|简体中文|
|时间轴匹配|BD版(VCB-Studio)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|未获取, 仅供学习交流|
