# 恋と嘘<br>戀愛與謊言<br>恋爱禁止的世界<br>Koi to Uso

<img src="img.jpg" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [@tsumugi630](https://twitter.com/tsumugi630/status/938328759811260416)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|雪飘字幕组|
|集数|EP 01-12|
|语言|简体中文|
|时间轴匹配|BD版(VCB-Studio)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|未获取, 仅供学习交流|

## 歌曲歌词信息

|主题曲|歌词语言 & 来源|
|-|-|
|かなしいうれしい|[日语歌词](https://utaten.com/lyric/ha17071804)|
|Can't you say|[日语歌词](https://utaten.com/lyric/mi17091301)|
