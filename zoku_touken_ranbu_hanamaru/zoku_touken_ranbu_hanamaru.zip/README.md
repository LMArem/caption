# 続 刀剣乱舞-花丸-<br>续 刀剑乱舞 -花丸-<br>Zoku Touken Ranbu: Hanamaru

<img src="img.jpg" width="100%" alt="img" align=center/><br>

<font size=2>***插图来源: [刀剣乱舞-花丸- 官方网站](http://touken-hanamaru.jp/index.html)***</font>

## 字幕信息

|项目|信息|
|-|-|
|源字幕制作者(组)|BiliBili md12572|
|集数|EP 01-12|
|语言|繁體中文|
|时间轴匹配|BD版(Moozzi2)|
|类型|手抄, 非字幕组|
|字幕组手抄 & 分享许可|未获取, 仅供学习交流|

## 歌曲歌词信息

|主题曲|歌词语言 & 来源|
|-|-|
|花丸印の日のもとで|[日语歌词](https://utaten.com/lyric/iz18112826)|
|奇しき巡りは粋な縁|[日语歌词](https://utaten.com/lyric/qk18016000)|
|めでたしつくりごと|[日语歌词](https://utaten.com/lyric/ya18013112)|
|みちゆき、寄り合い|[日语歌词](https://utaten.com/lyric/yc18020703)|
|花色衣|[日语歌词](https://utaten.com/lyric/yc18021414)|
|鈴生り時にて|[日语歌词](https://utaten.com/lyric/qk18021008)|
|一対の火花、秘め事に触れ|[日语歌词](https://utaten.com/lyric/qk18023006)|
|刃生道|[日语歌词](https://utaten.com/lyric/qk18030040)|
|閃の刻印|[日语歌词](https://utaten.com/lyric/qk18031021)|
